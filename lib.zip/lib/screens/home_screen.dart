import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../l10n/app_localizations.dart';
import '../widgets/language_switcher.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  // Constants for consistent spacing and sizing
  static const Color _brownColor = Color(0xFF4E342E);
  static const double _spacing = 16.0;
  static const double _cardElevation = 4.0;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFF5E8E2), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(_spacing),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      l10n.welcomeToAstro,
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.bold,
                        color: _brownColor,
                        shadows: [
                          Shadow(
                            color: Colors.black12,
                            offset: const Offset(0, 2),
                            blurRadius: 4,
                          ),
                        ],
                      ),
                    ),
                    const LanguageSwitcher(),
                  ],
                ),
                const SizedBox(height: _spacing),
                _buildZodiacSection(l10n),
                const SizedBox(height: _spacing),
                _buildAstroServicesSection(l10n),
                const SizedBox(height: _spacing),
                Text(
                  l10n.astrologers,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: _brownColor,
                  ),
                ),
                const SizedBox(height: _spacing / 2),
                _buildAstrologersSection(l10n),
                const SizedBox(height: _spacing),
                _buildVenusTransitSection(l10n),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: _brownColor,
        selectedItemColor: Colors.yellow[700],
        unselectedItemColor: Colors.white70,
        items: [
          BottomNavigationBarItem(icon: const Icon(Icons.home), label: l10n.home),
          BottomNavigationBarItem(icon: const Icon(Icons.person), label: l10n.astrologersTab),
          BottomNavigationBarItem(icon: const Icon(Icons.settings), label: l10n.services),
          BottomNavigationBarItem(icon: const Icon(Icons.notifications), label: l10n.notifications),
          BottomNavigationBarItem(icon: const Icon(Icons.account_circle), label: l10n.profile),
        ],
        currentIndex: 0,
        onTap: (index) {
          print("Navigated to index: $index");
        },
      ),
    );
  }

  Widget _buildZodiacSection(AppLocalizations l10n) {
    final zodiacs = [
      {'name': l10n.zodiacLeo, 'image': 'assets/leo.png'},
      {'name': l10n.zodiacCancer, 'image': 'assets/scorpio.png'},
      {'name': l10n.zodiacLibra, 'image': 'assets/leo.png'},
      {'name': l10n.zodiacScorpio, 'image': 'assets/scorpio.png'},
    ];
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: zodiacs.length,
        itemBuilder: (context, index) {
          final zodiac = zodiacs[index];
          return Padding(
            padding: const EdgeInsets.only(right: _spacing),
            child: Card(
              elevation: _cardElevation,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Container(
                width: 80,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_brownColor.withOpacity(0.9), Colors.yellow[700]!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(zodiac['image']!, width: 40, height: 40),
                    const SizedBox(height: 4),
                    Text(
                      zodiac['name']!,
                      style: const TextStyle(fontSize: 14, color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildAstroServicesSection(AppLocalizations l10n) {
    final services = [
      {'name': l10n.call, 'icon': Icons.phone},
      {'name': l10n.chat, 'icon': Icons.chat},
      {'name': l10n.video, 'icon': Icons.videocam},
      {'name': l10n.feedback, 'icon': Icons.feedback},
    ];
    return Card(
      elevation: _cardElevation,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(_spacing),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              l10n.astroServices,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: _brownColor,
              ),
            ),
            const SizedBox(height: _spacing / 2),
            GridView.count(
              crossAxisCount: 4,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: _spacing / 2,
              mainAxisSpacing: _spacing / 2,
              children: services.map((service) => Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: Colors.yellow[700],
                    child: Icon(
                      service['icon'] as IconData,
                      color: Colors.white,
                      size: 22,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    service['name']! as String,
                    style: const TextStyle(fontSize: 12, color: Colors.black87),
                    textAlign: TextAlign.center,
                  ),
                ],
              )).toList(),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () {
                  print("See all clicked");
                },
                child: Text(
                  l10n.seeAll,
                  style: TextStyle(color: Colors.yellow[700]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAstrologersSection(AppLocalizations l10n) {
    final astrologers = [
      {'name': l10n.acharyaVenkat, 'rating': '4.5'},
      {'name': l10n.acharyaAru, 'rating': '4.8'},
      {'name': l10n.acharyaVikram, 'rating': '4.2'},
    ];
    return Column(
      children: astrologers.map((astrologer) => Card(
        elevation: _cardElevation,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.only(bottom: _spacing / 2),
        child: ListTile(
          leading: const CircleAvatar(
            radius: 25,
            backgroundImage: NetworkImage('https://via.placeholder.com/50'),
          ),
          title: Text(
            astrologer['name']!,
            style: TextStyle(fontSize: 16, color: _brownColor),
          ),
          trailing: Text(
            '${astrologer['rating']!} ★',
            style: TextStyle(fontSize: 14, color: Colors.orange),
          ),
        ),
      )).toList(),
    );
  }

  Widget _buildVenusTransitSection(AppLocalizations l10n) {
    return Card(
      elevation: _cardElevation,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        padding: const EdgeInsets.all(_spacing),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.yellow[700]!, _brownColor.withOpacity(0.8)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              l10n.venusTransit,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: _spacing / 2),
            Text(
              l10n.venusTransitDescription,
              style: const TextStyle(fontSize: 14, color: Colors.white70),
            ),
            const SizedBox(height: _spacing / 2),
            ElevatedButton(
              onPressed: () {
                print("View more clicked");
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: _brownColor,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: const Text("View more"),
            ),
          ],
        ),
      ),
    );
  }
}